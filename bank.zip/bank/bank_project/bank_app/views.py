from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm, TransactionForm
from .models import Account, Transaction
import random


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Account.objects.create(user=user, account_number=str(
                random.randint(10000000, 99999999)), balance=0.0)
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard_view(request):
    account = Account.objects.get(user=request.user)
    transactions = Transaction.objects.filter(
        account=account).order_by('-timestamp')
    return render(request, 'dashboard.html', {'account': account, 'transactions': transactions})


@login_required
def transaction_view(request):
    account = Account.objects.get(user=request.user)
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.account = account
            if transaction.type == 'W' and account.balance < transaction.amount:
                form.add_error('amount', 'Insufficient balance')
            else:
                if transaction.type == 'W':
                    account.balance -= transaction.amount
                else:
                    account.balance += transaction.amount
                account.save()
                transaction.save()
                return redirect('dashboard')
    else:
        form = TransactionForm()
    return render(request, 'transaction.html', {'form': form})
